"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Droplets, Heart, Instagram, ExternalLink, Award, Leaf, Users, Zap, TrendingUp, Eye, Wifi, Camera, ArrowRight, Send } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

export default function Home() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")

  const handleCollabSubmit = () => {
    if (email && message) {
      alert(`¡Gracias por tu interés en colaborar! Te contactaremos pronto en ${email}`)
      setEmail("")
      setMessage("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 overflow-x-hidden">
      {/* Floating Animation Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-4 h-4 bg-cyan-400 rounded-full animate-bounce opacity-70 delay-1000"></div>
        <div className="absolute top-40 right-20 w-6 h-6 bg-emerald-400 rounded-full animate-pulse opacity-60 delay-500"></div>
        <div className="absolute bottom-32 left-1/4 w-3 h-3 bg-yellow-400 rounded-full animate-ping opacity-50"></div>
        <div className="absolute bottom-20 right-1/3 w-5 h-5 bg-pink-400 rounded-full animate-bounce opacity-60 delay-700"></div>
      </div>

      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-cyan-500/30 sticky top-0 z-50 transition-all duration-300">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 group">
              <div className="relative">
                <Droplets className="h-10 w-10 text-cyan-400 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12" />
                <div className="absolute inset-0 h-10 w-10 bg-cyan-400/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              </div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 via-emerald-400 to-blue-400 bg-clip-text text-transparent hover:from-purple-400 hover:to-pink-400 transition-all duration-500">
                XilemaTech
              </h1>
            </div>
            <nav className="hidden lg:flex items-center space-x-8">
              {['Inicio', 'Proyecto', 'Funcionamiento', 'Resultados', 'Visión', 'Colaborar', 'Ayudar'].map((item, index) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-white/80 hover:text-cyan-400 transition-all duration-300 relative group font-medium"
                >
                  {item}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-400 group-hover:w-full transition-all duration-300"></span>
                </a>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="py-20 px-4 relative">
        <div className="container mx-auto text-center relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="mb-8 animate-fade-in-up">
              <Badge className="mb-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 px-6 py-2 text-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-purple-500/50">
                <Award className="w-5 h-5 mr-2 animate-pulse" />
                Reconocido en ExpoCiencias 2025
              </Badge>
            </div>

            <h2 className="text-6xl md:text-8xl font-black mb-8 animate-fade-in-up delay-200">
              <span className="bg-gradient-to-r from-cyan-400 via-emerald-400 to-blue-400 bg-clip-text text-transparent hover:from-purple-400 hover:to-pink-400 transition-all duration-1000 cursor-default">
                Purificando el agua.
              </span>
              <br />
              <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent hover:from-yellow-400 hover:to-orange-400 transition-all duration-1000 cursor-default">
                Protegiendo el futuro.
              </span>
            </h2>

            <div className="relative mb-12 group animate-fade-in-up delay-400">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-500"></div>
              <div className="relative bg-black/30 backdrop-blur-md rounded-3xl p-8 border border-cyan-500/30 hover:border-purple-500/50 transition-all duration-500">
                <div className="relative w-full h-80 overflow-hidden rounded-2xl">
                  <Image
                    src="/crystal-water.jpg"
                    alt="Agua cristalina fluyendo"
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <p className="text-lg font-semibold">Agua cristalina - El futuro de la purificación</p>
                  </div>
                </div>
              </div>
            </div>

            <p className="text-xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed animate-fade-in-up delay-600">
              Soy estudiante y creé este proyecto llamado <span className="text-cyan-400 font-semibold">XilemaTech</span> para ayudar a comunidades sin acceso a agua limpia.
              Lo desarrollé con <span className="text-emerald-400 font-semibold">tecnología natural y sensores inteligentes</span>, y participé con él en ExpoCiencias 2025,
              donde fue reconocido por su <span className="text-purple-400 font-semibold">impacto y sustentabilidad</span>.
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center animate-fade-in-up delay-800">
              <Button
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-purple-500 hover:to-pink-600 text-white border-0 px-8 py-4 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/50 group"
                onClick={() => document.getElementById('ayudar')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Heart className="w-6 h-6 mr-3 group-hover:animate-pulse" />
                Apoyar el Proyecto
                <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-4 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-cyan-400/50"
                onClick={() => document.getElementById('proyecto')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Conocer Más
                <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Sobre el Proyecto Section */}
      <section id="proyecto" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/50 to-purple-900/50"></div>
        <div className="container mx-auto relative z-10">
          <div className="text-center mb-16">
            <h3 className="text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              💧 Sobre el proyecto
            </h3>
            <h4 className="text-3xl text-gray-300 mb-8">¿Qué es XilemaTech?</h4>
          </div>

          <div className="max-w-5xl mx-auto mb-16">
            <Card className="bg-gradient-to-r from-cyan-900/30 to-purple-900/30 border-cyan-500/30 backdrop-blur-md hover:border-purple-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20">
              <CardContent className="p-12">
                <p className="text-2xl text-gray-200 leading-relaxed text-center">
                  Es un <span className="text-cyan-400 font-bold">filtro ecológico</span> que limpia el agua usando materiales naturales como
                  <span className="text-emerald-400 font-semibold"> xilema de girasol, plantas acuáticas, carbón activado, plata coloidal, y energía solar</span>.
                </p>
              </CardContent>
            </Card>
          </div>

          <h5 className="text-3xl font-bold text-center mb-12 text-white">Modelos Innovadores:</h5>
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <Card
              className="bg-gradient-to-br from-yellow-900/30 to-orange-900/30 border-yellow-500/30 backdrop-blur-md hover:border-orange-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/20 group cursor-pointer"
              onMouseEnter={() => setHoveredCard('solar')}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <CardHeader>
                <CardTitle className="flex items-center text-yellow-400 text-2xl">
                  <Zap className={`w-8 h-8 mr-3 transition-transform duration-300 ${hoveredCard === 'solar' ? 'rotate-12 scale-110' : ''}`} />
                  Filtro Solar Multicapa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Filtro solar por gravedad multicapa con <span className="text-yellow-400 font-semibold">UV y mineralización</span> para purificación completa.
                </p>
              </CardContent>
            </Card>

            <Card
              className="bg-gradient-to-br from-green-900/30 to-emerald-900/30 border-green-500/30 backdrop-blur-md hover:border-emerald-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-green-500/20 group cursor-pointer"
              onMouseEnter={() => setHoveredCard('bio')}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <CardHeader>
                <CardTitle className="flex items-center text-green-400 text-2xl">
                  <Leaf className={`w-8 h-8 mr-3 transition-transform duration-300 ${hoveredCard === 'bio' ? 'rotate-12 scale-110' : ''}`} />
                  Bioparque de Pozas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Bioparque de pozas con <span className="text-green-400 font-semibold">plantas fitorremediadoras</span>: lenteja de agua, carrizo, zapito, verdolaga, etc.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Funcionamiento Section */}
      <section id="funcionamiento" className="py-20 px-4 relative">
        <div className="container mx-auto">
          <h3 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            ⚙️ ¿Cómo funciona?
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {[
              { title: "Físico", icon: "🪨", desc: "Filtración por arena, grava, piedra y zeolita para eliminar partículas sólidas." },
              { title: "Biológico", icon: "🌱", desc: "Plantas limpian metales y bacterias. Las almejas se cierran si hay contaminantes." },
              { title: "Químico", icon: "⚗️", desc: "Carbón activado, plata coloidal y mineralización para purificación química." },
              { title: "UV", icon: "☀️", desc: "Desinfección final ultravioleta para eliminar microorganismos patógenos." },
              { title: "Xilema Vegetal", icon: "🌻", desc: "Microfiltro natural que detiene bacterias usando tejido vegetal de girasol." },
              { title: "pH Final", icon: "🎯", desc: "pH final ideal de 8, perfecto para consumo humano y salud óptima." }
            ].map((process, index) => (
              <Card
                key={process.title}
                className="bg-gradient-to-br from-black/40 to-gray-900/40 border-cyan-500/30 backdrop-blur-md hover:border-purple-500/50 transition-all duration-500 hover:scale-110 hover:shadow-2xl group cursor-pointer"
              >
                <CardHeader className="text-center">
                  <div className="text-4xl mb-4 group-hover:scale-125 transition-transform duration-300">
                    {process.icon}
                  </div>
                  <CardTitle className="text-xl text-white group-hover:text-cyan-400 transition-colors duration-300">
                    {process.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 leading-relaxed group-hover:text-white transition-colors duration-300">
                    {process.desc}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Resultados Section */}
      <section id="resultados" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/50 to-blue-900/50"></div>
        <div className="container mx-auto relative z-10">
          <h3 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
            📊 Resultados Impresionantes
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {[
              { icon: TrendingUp, title: "Turbidez", value: "200 NTU → <10 NTU" },
              { icon: Eye, title: "Calidad", value: "Mejora en olor, color y sabor" },
              { icon: Leaf, title: "Ecológico", value: "Sin químicos, sin residuos" },
              { icon: Zap, title: "Autónomo", value: "Funciona sin electricidad de red" }
            ].map((result, index) => (
              <Card
                key={result.title}
                className="text-center bg-gradient-to-br from-black/40 to-gray-900/40 border-cyan-500/30 backdrop-blur-md hover:border-purple-500/50 transition-all duration-500 hover:scale-110 hover:shadow-2xl group cursor-pointer"
              >
                <CardContent className="p-8">
                  <result.icon className="w-16 h-16 text-cyan-400 mx-auto mb-6 group-hover:text-purple-400 group-hover:scale-125 transition-all duration-300" />
                  <h4 className="font-bold text-white mb-4 text-xl group-hover:text-cyan-400 transition-colors duration-300">
                    {result.title}
                  </h4>
                  <p className="text-gray-300 leading-relaxed group-hover:text-white transition-colors duration-300">
                    {result.value}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Visión Futura Section */}
      <section id="vision" className="py-20 px-4 relative">
        <div className="container mx-auto">
          <h3 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
            🚀 Visión Futura
          </h3>
          <div className="grid md:grid-cols-2 gap-12 mb-16 max-w-6xl mx-auto">
            <Card className="bg-gradient-to-br from-cyan-900/30 to-blue-900/30 border-cyan-500/30 backdrop-blur-md hover:border-blue-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20 group">
              <CardHeader>
                <CardTitle className="flex items-center text-cyan-400 text-2xl">
                  <Wifi className="w-8 h-8 mr-3 group-hover:animate-pulse" />
                  Sensores IoT Inteligentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Monitoreo en <span className="text-cyan-400 font-semibold">tiempo real</span> de pH, oxígeno disuelto, salinidad, cloro, pureza y conductividad.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-indigo-900/30 to-purple-900/30 border-indigo-500/30 backdrop-blur-md hover:border-purple-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-indigo-500/20 group">
              <CardHeader>
                <CardTitle className="flex items-center text-indigo-400 text-2xl">
                  <Camera className="w-8 h-8 mr-3 group-hover:animate-bounce" />
                  Cámaras con IA
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Detectan basura, mapean contaminación y envían <span className="text-indigo-400 font-semibold">alertas automáticas</span>.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Card className="bg-gradient-to-r from-indigo-900/40 to-cyan-900/40 border-purple-500/30 backdrop-blur-md max-w-4xl mx-auto hover:scale-105 transition-all duration-500">
              <CardContent className="p-12">
                <p className="text-2xl text-gray-200 italic leading-relaxed">
                  <span className="text-purple-400 font-bold">"These tools can send alerts if the water becomes polluted, so action can be taken quickly."</span>
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Colaboración Section */}
      <section id="colaborar" className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/50 to-teal-900/50"></div>
        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-5xl font-bold mb-8 bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              🤝 ¿Quieres Colaborar?
            </h3>
            <p className="text-xl text-gray-300 mb-12 leading-relaxed">
              Únete a nuestro equipo y ayúdanos a llevar agua limpia a más comunidades.
              Buscamos voluntarios, investigadores, ingenieros y personas apasionadas por el cambio social.
            </p>

            <Card className="bg-gradient-to-br from-emerald-900/40 to-teal-900/40 border-emerald-500/30 backdrop-blur-md hover:border-teal-500/50 transition-all duration-500">
              <CardContent className="p-8">
                <form
                  action="https://formspree.io/f/xpzvjqeo"
                  method="POST"
                  className="space-y-6"
                >
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <input
                        type="email"
                        name="email"
                        placeholder="Tu email"
                        required
                        className="w-full p-4 rounded-xl bg-black/30 border border-emerald-500/30 text-white placeholder-gray-400 focus:border-emerald-400 focus:outline-none transition-all duration-300"
                      />
                    </div>
                    <div>
                      <input
                        type="text"
                        name="nombre"
                        placeholder="Tu nombre"
                        required
                        className="w-full p-4 rounded-xl bg-black/30 border border-emerald-500/30 text-white placeholder-gray-400 focus:border-emerald-400 focus:outline-none transition-all duration-300"
                      />
                    </div>
                  </div>
                  <div>
                    <textarea
                      name="mensaje"
                      placeholder="¿Cómo te gustaría colaborar con XilemaTech?"
                      required
                      rows={4}
                      className="w-full p-4 rounded-xl bg-black/30 border border-emerald-500/30 text-white placeholder-gray-400 focus:border-emerald-400 focus:outline-none transition-all duration-300 resize-none"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full md:w-auto bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/50"
                  >
                    <Send className="w-5 h-5 mr-2" />
                    Enviar Solicitud
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Instagram Section */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-900/50 to-purple-900/50"></div>
        <div className="container mx-auto text-center relative z-10">
          <h3 className="text-5xl font-bold mb-16 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
            📱 Síguenos
          </h3>
          <div className="flex justify-center">
            <Card className="bg-gradient-to-br from-pink-900/40 to-purple-900/40 border-pink-500/30 backdrop-blur-md p-8 hover:border-purple-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-pink-500/20 group">
              <CardContent className="flex flex-col items-center space-y-6">
                <Instagram className="w-16 h-16 text-pink-400 group-hover:scale-125 group-hover:rotate-12 transition-all duration-300" />
                <h4 className="text-2xl font-semibold text-white group-hover:text-pink-400 transition-colors duration-300">
                  Síguenos en Instagram
                </h4>
                <p className="text-gray-300 mb-6 group-hover:text-white transition-colors duration-300">
                  Escanea el código QR para seguir nuestras actualizaciones
                </p>
                <div className="bg-white/10 p-6 rounded-2xl shadow-inner group-hover:bg-white/20 transition-all duration-300">
                  <Image
                    src="/instagram-qr.png"
                    alt="Código QR de Instagram"
                    width={200}
                    height={200}
                    className="rounded-lg transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <Badge variant="secondary" className="bg-pink-500/20 text-pink-300 px-4 py-2 text-lg border border-pink-500/30">
                  @xilematech.oficial
                </Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Donaciones Section */}
      <section id="ayudar" className="py-20 px-4 relative">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-5xl font-bold mb-8 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              💚 Cómo ayudar
            </h3>
            <p className="text-xl text-gray-300 mb-16 leading-relaxed">
              Tu ayuda lleva <span className="text-cyan-400 font-semibold">agua limpia</span> a quienes más lo necesitan.
            </p>

            <Card className="bg-gradient-to-r from-blue-900/40 to-cyan-900/40 text-white border-blue-500/30 backdrop-blur-md hover:border-cyan-500/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/20">
              <CardHeader>
                <CardTitle className="text-3xl mb-4">Donar con PayPal</CardTitle>
                <CardDescription className="text-blue-200 text-lg">
                  Donación segura y confiable
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-gray-100 w-full md:w-auto px-8 py-4 text-lg font-semibold rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg group"
                  onClick={() => window.open('https://www.paypal.me/xilematechoficial', '_blank')}
                >
                  <Heart className="w-6 h-6 mr-3 group-hover:animate-pulse" />
                  Donar Ahora
                  <ExternalLink className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>
                <p className="text-sm text-blue-200 mt-6 text-lg">
                  paypal.me/xilematechoficial
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/80 backdrop-blur-lg text-white py-16 px-4 relative">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6 group">
            <div className="relative">
              <Droplets className="h-8 w-8 text-cyan-400 group-hover:scale-110 transition-transform duration-300" />
              <div className="absolute inset-0 h-8 w-8 bg-cyan-400/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-300"></div>
            </div>
            <h4 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              XilemaTech
            </h4>
          </div>
          <p className="text-gray-400 mb-6 text-lg">
            Purificando el agua • Protegiendo el futuro • ExpoCiencias 2025
          </p>
          <div className="border-t border-gray-700 pt-6">
            <p className="text-sm text-gray-500">
              © 2025 XilemaTech. Creando un futuro más sustentable.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
